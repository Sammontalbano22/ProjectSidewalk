package graph;

import static org.junit.Assert.*;
import org.junit.FixMethodOrder;

import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.net.URL;
import java.io.FileNotFoundException;

import java.util.LinkedList;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ShortestPathsTest {


    /* Returns the Graph loaded from the file with filename fn. */
    private Graph loadBasicGraph(String fn) {
        Graph result = null;
        try {
          result = ShortestPaths.parseGraph("basic", fn);
        } catch (FileNotFoundException e) {
          fail("Could not find graph " + fn);
        }
        return result;
    }

    /** Dummy test case demonstrating syntax to create a graph from scratch.
     * Write your own tests below. */
    @Test
    public void test00Nothing() {
        Graph g = new Graph();
        Node a = g.getNode("A");
        Node b = g.getNode("B");
        g.addEdge(a, b, 1);

        // sample assertion statements:
        assertTrue(true);
        assertEquals(2+2, 4);
    }

    /** Minimal test case to check the path from A to B in Simple0.txt */
    @Test
    public void test01Simple0() {
        Graph g = loadBasicGraph("Simple0.txt");
        g.report();
        ShortestPaths sp = new ShortestPaths();
        Node a = g.getNode("A");
        sp.compute(a);
        Node b = g.getNode("B");
        LinkedList<Node> abPath = sp.shortestPath(b);
        assertEquals(abPath.size(), 2);
        assertEquals(abPath.getFirst(), a);
        assertEquals(abPath.getLast(),  b);
        assertEquals(sp.shortestPathLength(b), 1.0, 1e-6);
    }

    @Test
    public void test02Simple2() {
        Graph gr = loadBasicGraph("Simple2.txt");
        gr.report();
        ShortestPaths sp = new ShortestPaths();
        Node h = gr.getNode("H");
        sp.compute(h);
        Node a = g.getNode("A");
        Node b = g.getNode("B");
        Node c = g.getNode("C");
        Node d = g.getNode("D");
        Node e = g.getNode("E");
        Node f = g.getNode("F");
        Node g = g.getNode("G");
        Node i = g.getNode("I");
        Node j = g.getNode("J");
        LinkedList<Node> haPath = sp.shortestPath(a);
        assertEquals(haPath.size(), 3);
        LinkedList<Node> hbPath = sp.shortestPath(b);
        assertEquals(haPath.size(), 4);

        assertEquals(sp.shortestPathLength(a), 5.0, 1e-6);
        assertEquals(sp.shortestPathLength(b), 9.0, 1e-6);      
        assertEquals(sp.shortestPathLength(c), 11.0, 1e-6);
        assertEquals(sp.shortestPathLength(d), 1.0, 1e-6);
        assertEquals(sp.shortestPathLength(e), 5.0, 1e-6);
        assertEquals(sp.shortestPathLength(f), 8.0, 1e-6);
        assertEquals(sp.shortestPathLength(g), 14.0, 1e-6);
        assertEquals(sp.shortestPathLength(i), 9.0, 1e-6);
        assertEquals(sp.shortestPathLength(j), 11.0, 1e-6);

    }

    /* Pro tip: unless you include @Test on the line above your method header,
     * gradle test will not run it! This gets me every time. */
}
